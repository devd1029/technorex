﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.DataAccess;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class CandidateController : Controller
    {
        // GET: Candidate
        public ActionResult Index()
        {
            ShowAllCandidateDetails();
            return View();
        }

        // GET: /Candidate/
        [HttpGet]
        public ActionResult InsertCandidate()
        {
            return View();
        }
        [HttpPost]
        public ActionResult InsertCandidate(Candidate objCandidate)
        {
           
            if (ModelState.IsValid) //checking model is valid or not
            {
                DataAccessLayer objDB = new DataAccessLayer();
                string result = objDB.InsertData(objCandidate);
                TempData["result"] = result;
                ModelState.Clear(); //clearing model
                return View();
            }
            else
            {
                ViewData["result"] = "Error Saving the data as Fileds are not valid";
                ModelState.AddModelError("", "Error in saving data");
                return View();
            }
        }

        [HttpGet]
        public ActionResult ShowAllCandidateDetails()
        {
            Candidate CandidateObj = new Candidate();
            DataAccessLayer dataObj = new DataAccessLayer();
             CandidateObj.ShowAllCandidate = dataObj.Selectalldata();
            if(CandidateObj.ShowAllCandidate != null)
            {
                return View(CandidateObj.ShowAllCandidate);
            }
            else
            {
                
                return View();
            }
           
        }

        [HttpGet]
        public ActionResult Edit(string ID)
        {
            Candidate objCandidate = new Candidate();
            DataAccessLayer objDB = new DataAccessLayer(); //calling class DBdata
            return View(objDB.SelectDatabyID(ID));
        }
        [HttpPost]
        public ActionResult Edit(Candidate objCandidate)
        {
            
            if (ModelState.IsValid) //checking model is valid or not
            {
                DataAccessLayer objDB = new DataAccessLayer(); //calling class DBdata
                string result = objDB.UpdateData(objCandidate);
                TempData["result"] = result;
                ModelState.Clear(); //clearing model
                return View();
            }
            else
            {
                ModelState.AddModelError("", "Error in saving data");
                return View();
            }
        }

        [HttpGet]
        public ActionResult Delete(string ID)
        {
            Candidate objCandidate = new Candidate();
            DataAccessLayer objDB = new DataAccessLayer(); //calling class DBdata
            return View(objDB.SelectDatabyID(ID));
        }

        [HttpPost]
        public ActionResult Delete(Candidate objCandidate)
        {
            DataAccessLayer objDB = new DataAccessLayer();
            string result = objDB.DeleteData(objCandidate);
            ViewData["result"] = result;
            ModelState.Clear(); //clearing model
            return View();
        }
    }
    
}