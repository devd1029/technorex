﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using WebApplication1.Models;

namespace WebApplication1.DataAccess
{
    public class DataAccessLayer
    {
        public string InsertData(Candidate objcust)
        {

            SqlConnection con = null;
            string result = "";
            try
            {
                con = new SqlConnection(ConfigurationManager.AppSettings["mycon"].ToString());
                SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_Candidate", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CandidateID", 0);
                cmd.Parameters.AddWithValue("@FirstName", objcust.FirstName);
                cmd.Parameters.AddWithValue("@LastName", objcust.LastName);
                cmd.Parameters.AddWithValue("@EmailID", objcust.EmailID);
                cmd.Parameters.AddWithValue("@PhoneCode", objcust.PhoneCode);
                cmd.Parameters.AddWithValue("@Mobileno", objcust.Mobileno);
                cmd.Parameters.AddWithValue("@City", objcust.City);
                cmd.Parameters.AddWithValue("@State", objcust.State);
                cmd.Parameters.AddWithValue("@Country", objcust.Country);
                cmd.Parameters.AddWithValue("@Pincode", objcust.Pincode);
                cmd.Parameters.AddWithValue("@ProfilePic", objcust.ProfilePic);
                cmd.Parameters.AddWithValue("@Query", 1);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch(Exception ex)
            {
                return result = ex.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public string UpdateData(Candidate objcust)
        {
            SqlConnection con = null;
            string result = "";
            try
            {
                con = new SqlConnection(ConfigurationManager.AppSettings["mycon"].ToString());
                SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_Candidate", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CandidateID", objcust.CandidateID);
                cmd.Parameters.AddWithValue("@FirstName", objcust.FirstName);
                cmd.Parameters.AddWithValue("@LastName", objcust.LastName);
                cmd.Parameters.AddWithValue("@EmailID", objcust.EmailID);
                cmd.Parameters.AddWithValue("@PhoneCode", objcust.PhoneCode);
                cmd.Parameters.AddWithValue("@Mobileno", objcust.Mobileno);
                cmd.Parameters.AddWithValue("@City", objcust.City);
                cmd.Parameters.AddWithValue("@State", objcust.State);
                cmd.Parameters.AddWithValue("@Country", objcust.Country);
                cmd.Parameters.AddWithValue("@Pincode", objcust.Pincode);
                cmd.Parameters.AddWithValue("@ProfilePic", objcust.ProfilePic);
                cmd.Parameters.AddWithValue("@Query", 2);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch
            {
                return result = "";
            }
            finally
            {
                con.Close();
            }
        }

        public string DeleteData(Candidate objcust)
        {
            SqlConnection con = null;
            string result = "";
            try
            {
                con = new SqlConnection(ConfigurationManager.AppSettings["mycon"].ToString());
                SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_Candidate", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CandidateID", objcust.CandidateID);
                cmd.Parameters.AddWithValue("@FirstName", objcust.FirstName);
                cmd.Parameters.AddWithValue("@LastName", objcust.LastName);
                cmd.Parameters.AddWithValue("@EmailID", objcust.EmailID);
                cmd.Parameters.AddWithValue("@PhoneCode", objcust.PhoneCode);
                cmd.Parameters.AddWithValue("@Mobileno", objcust.Mobileno);
                cmd.Parameters.AddWithValue("@City", objcust.City);
                cmd.Parameters.AddWithValue("@State", objcust.State);
                cmd.Parameters.AddWithValue("@Country", objcust.Country);
                cmd.Parameters.AddWithValue("@Pincode", objcust.Pincode);
                cmd.Parameters.AddWithValue("@ProfilePic", objcust.ProfilePic);
                cmd.Parameters.AddWithValue("@Query", 3);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch
            {
                return result = "";
            }
            finally
            {
                con.Close();
            }
        }

        public List<Candidate> Selectalldata()
        {
            SqlConnection con = null;

            DataSet ds = null;
            List<Candidate> custlist = null;
            try
            {
                var connetionString = ConfigurationManager.AppSettings["mycon"].ToString();
                con = new SqlConnection(connetionString);
                SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_Candidate", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CandidateID", null);
                cmd.Parameters.AddWithValue("@FirstName", null);
                cmd.Parameters.AddWithValue("@LastName", null);
                cmd.Parameters.AddWithValue("@EmailID", null);
                cmd.Parameters.AddWithValue("@Mobileno", null);
                cmd.Parameters.AddWithValue("@City", null);
                cmd.Parameters.AddWithValue("@State", null);
                cmd.Parameters.AddWithValue("@Country", null);
                cmd.Parameters.AddWithValue("@Pincode", null);
                cmd.Parameters.AddWithValue("@ProfilePic", null);
                cmd.Parameters.AddWithValue("@Query", 4);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                custlist = new List<Candidate>();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    Candidate cobj = new Candidate();
                    cobj.CandidateID = Convert.ToInt32(ds.Tables[0].Rows[i]["CandidateID"].ToString());
                    cobj.FirstName = ds.Tables[0].Rows[i]["FirstName"].ToString();
                    cobj.LastName = ds.Tables[0].Rows[i]["LastName"].ToString();
                    cobj.EmailID = ds.Tables[0].Rows[i]["EmailID"].ToString();
                    cobj.PhoneCode = ds.Tables[0].Rows[i]["PhoneCode"].ToString();
                    cobj.Mobileno = ds.Tables[0].Rows[i]["Mobileno"].ToString();
                    cobj.City = ds.Tables[0].Rows[i]["City"].ToString();

                    cobj.State = ds.Tables[0].Rows[i]["State"].ToString();
                    cobj.Country = ds.Tables[0].Rows[i]["Country"].ToString();
                    cobj.Pincode = Convert.ToInt32(ds.Tables[0].Rows[i]["Pincode"].ToString());
                    cobj.ProfilePic = ds.Tables[0].Rows[i]["ProfilePic"].ToString();
                   
                   
                    custlist.Add(cobj);
                }
                return custlist;
            }
            catch(Exception e)
            {
                return custlist;
            }
            finally
            {
                con.Close();
            }
        }

        public Candidate SelectDatabyID(string CandidateID)
        {
            SqlConnection con = null;
            DataSet ds = null;
            Candidate cobj = null;
            try
            {
                con = new SqlConnection(ConfigurationManager.AppSettings["mycon"].ToString());
                SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_Candidate", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CandidateID", CandidateID);
                cmd.Parameters.AddWithValue("@FirstName", null);
                cmd.Parameters.AddWithValue("@LastName", null);
                cmd.Parameters.AddWithValue("@EmailID", null);
                cmd.Parameters.AddWithValue("@Mobileno", null);
                cmd.Parameters.AddWithValue("@City", null);
                cmd.Parameters.AddWithValue("@State", null);
                cmd.Parameters.AddWithValue("@Country", null);
                cmd.Parameters.AddWithValue("@Pincode", null);
                cmd.Parameters.AddWithValue("@ProfilePic", null);
                cmd.Parameters.AddWithValue("@Query", 5);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cobj = new Candidate();
                    cobj.CandidateID = Convert.ToInt32(ds.Tables[0].Rows[i]["CandidateID"].ToString());
                    cobj.FirstName = ds.Tables[0].Rows[i]["FirstName"].ToString();
                    cobj.LastName = ds.Tables[0].Rows[i]["LastName"].ToString();
                    cobj.EmailID = ds.Tables[0].Rows[i]["EmailID"].ToString();
                    cobj.PhoneCode = ds.Tables[0].Rows[i]["PhoneCode"].ToString();
                    cobj.Mobileno = ds.Tables[0].Rows[i]["Mobileno"].ToString();
                    cobj.City = ds.Tables[0].Rows[i]["City"].ToString();
                    cobj.State = ds.Tables[0].Rows[i]["State"].ToString();
                    cobj.Country = ds.Tables[0].Rows[i]["Country"].ToString();
                    cobj.Pincode = Convert.ToInt32(ds.Tables[0].Rows[i]["Pincode"].ToString());
                    cobj.ProfilePic = ds.Tables[0].Rows[i]["ProfielPic"].ToString();
                }
                return cobj;
            }
            catch
            {
                return cobj;
            }
            finally
            {
                con.Close();
            }
        }
    }
}