﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Candidate
    {
        [Key]
        public int CandidateID { get; set; }

        [Required(ErrorMessage = "Enter Name")]
        public string FirstName { get; set; }

        public string LastName { get; set; }

        [Required(ErrorMessage = "Enter EmailID")]
        public string EmailID { get; set; }

        public string PhoneCode { get; set; }

        [Required(ErrorMessage = "Enter Mobile Number")]
        public string Mobileno { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        [Required(ErrorMessage = "Please Select the Country")]

        public string Country { get; set; }

        public int Pincode { get; set; }
        public Address Address { get; internal set; }

        public string ProfilePic { get; set; }


        public List<Candidate> ShowAllCandidate { get; internal set; }
    }

    public class Address
    {
        public string City { get; set; }

        public string State { get; set; }

        [Required(ErrorMessage = "Please Select the Country")]

        public string Country { get; set; }

        public int Pincode { get; set; }
    }
}
